//
//  CatAPIProjectApp.swift
//  CatAPIProject
//
//  Created by Karishma Patil on 16.10.24.
//

import SwiftUI

@main
struct CatAPIProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
